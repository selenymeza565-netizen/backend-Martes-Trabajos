package co.edu.cesde.proyectointegradormarte.Domain.Model.Exception;

public class RecursoEncontradoException extends RuntimeException {
    public RecursoEncontradoException(String message) {
        super(message);
    }
}
