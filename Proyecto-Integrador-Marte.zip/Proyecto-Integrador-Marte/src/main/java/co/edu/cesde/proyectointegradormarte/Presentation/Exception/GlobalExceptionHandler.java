package co.edu.cesde.proyectointegradormarte.Presentation.Exception;

import co.edu.cesde.proyectointegradormarte.Domain.Model.Exception.DatoNuloException;
import co.edu.cesde.proyectointegradormarte.Domain.Model.Exception.DatosInvalidosException;
import co.edu.cesde.proyectointegradormarte.Domain.Model.Exception.RecursoEncontradoException;
import co.edu.cesde.proyectointegradormarte.Domain.Model.Exception.RecursoNoEncontradoExeption;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RecursoNoEncontradoExeption.class)
    public ResponseEntity<Map<String, String>> noEncontrado(
            RecursoNoEncontradoExeption ex
    ) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(Map.of("mensaje", ex.getMessage()));
    }

    @ExceptionHandler(RecursoEncontradoException.class)
    public ResponseEntity<Map<String, String>> yaExiste(
            RecursoEncontradoException ex
    ) {
        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(Map.of("mensaje", ex.getMessage()));
    }

    @ExceptionHandler(DatosInvalidosException.class)
    public ResponseEntity<Map<String, String>> datosInvalidos(
            DatosInvalidosException ex
    ) {
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(Map.of("mensaje", ex.getMessage()));
    }

    @ExceptionHandler(DatoNuloException.class)
    public ResponseEntity<Map<String, String>> datoNulo(
            DatoNuloException ex
    ) {
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(Map.of("mensaje", ex.getMessage()));
    }
}