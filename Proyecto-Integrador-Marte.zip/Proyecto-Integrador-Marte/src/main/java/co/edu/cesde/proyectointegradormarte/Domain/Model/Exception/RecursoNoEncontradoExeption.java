package co.edu.cesde.proyectointegradormarte.Domain.Model.Exception;

public class RecursoNoEncontradoExeption extends RuntimeException {
    public RecursoNoEncontradoExeption(String message) {
        super(message);
    }
}
