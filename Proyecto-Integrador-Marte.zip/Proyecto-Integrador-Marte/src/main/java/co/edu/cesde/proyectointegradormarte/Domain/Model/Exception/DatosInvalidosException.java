package co.edu.cesde.proyectointegradormarte.Domain.Model.Exception;

public class DatosInvalidosException extends RuntimeException {
    public DatosInvalidosException(String message) {
        super(message);
    }
}
