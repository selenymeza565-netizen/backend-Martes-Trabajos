package co.edu.cesde.proyectointegradormarte.Domain.Model.Exception;

public class DatoNuloException extends RuntimeException {
    public DatoNuloException(String message) {
        super(message);
    }
}
