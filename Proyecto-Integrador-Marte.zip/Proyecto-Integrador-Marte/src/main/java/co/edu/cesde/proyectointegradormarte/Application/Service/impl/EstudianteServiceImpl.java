package co.edu.cesde.proyectointegradormarte.Application.Service.impl;

import co.edu.cesde.proyectointegradormarte.Application.Service.EstudianteService;
import co.edu.cesde.proyectointegradormarte.Domain.Model.Estudiante;
import co.edu.cesde.proyectointegradormarte.Domain.Model.Exception.DatoNuloException;
import co.edu.cesde.proyectointegradormarte.Domain.Model.Exception.RecursoEncontradoException;
import co.edu.cesde.proyectointegradormarte.Domain.Model.Exception.RecursoNoEncontradoExeption;
import co.edu.cesde.proyectointegradormarte.Infrastructure.Repository.EstudianteRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EstudianteServiceImpl implements EstudianteService {

    private final EstudianteRepository estudianteRepository;

    public EstudianteServiceImpl(
            EstudianteRepository estudianteRepository
    ) {
        this.estudianteRepository = estudianteRepository;
    }

    @Override
    public Estudiante guardar(Estudiante estudiante) {
        if (estudiante == null) {
            throw new DatoNuloException("El estudiante no puede ser nulo");
        }
        if (estudiante.getId() != 0
                && estudianteRepository.existsById(estudiante.getId())) {
            throw new RecursoEncontradoException("El estudiante ya existe");
        }
        return estudianteRepository.save(estudiante);
    }

    @Override
    public Estudiante buscar(Long id) {
        return estudianteRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoExeption(
                        "Estudiante no encontrado con id " + id
                ));
    }

    @Override
    public List<Estudiante> listar() {
        return estudianteRepository.findAll();
    }

    @Override
    public Estudiante actualizar(
            Long id,
            Estudiante estudiante
    ) {
        if (!estudianteRepository.existsById(id)) {
            throw new RecursoNoEncontradoExeption(
                    "Estudiante no encontrado con id " + id
            );
        }
        estudiante.setId(id);
        return estudianteRepository.save(estudiante);
    }

    @Override
    public void borrar(Long id) {
        if (!estudianteRepository.existsById(id)) {
            throw new RecursoNoEncontradoExeption(
                    "Estudiante no encontrado con id " + id
            );
        }
        estudianteRepository.deleteById(id);
    }
}